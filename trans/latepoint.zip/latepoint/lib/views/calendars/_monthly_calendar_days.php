<?php
OsBookingHelper::generate_monthly_calendar_days($target_date->format('Y-m-d'), $calendar_settings);