Hi {customer_full_name},
<br/>
You have requested to change password for this account.
<br/>
Use this secret key to reset your password: <strong>{token}</strong>
<br/>
Best Regards!