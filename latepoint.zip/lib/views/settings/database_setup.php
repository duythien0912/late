<?php
_e('Database Updated', 'latepoint');