<?php 
class OsDefaultsHelper {


  public static function get_something(){
  }


}